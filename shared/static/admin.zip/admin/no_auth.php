<div style="position: relative; width: 500px; margin: 0px auto;" class="aligner">
    <div class="error">%common.admin.no_auth%</div>
</div>