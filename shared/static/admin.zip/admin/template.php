<html>
<head>
<title>%common.admin.html_title%</title>
<link rel="stylesheet" type="text/css" href="/janix/static/shared/stylesheets/admin/style.css" />
</head>
<body>
    <div class="wrapper">
        <div class="logo"></div>
        <div class="navigation"></div>
        <div class="clear"></div>
        <div class="content">{CONTENT}</div>
    </div>
</body>
</html>