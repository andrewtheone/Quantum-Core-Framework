<div class="categories aligner">
    <div class="category">
        <div class="title">Website settings</div>
        <div class="operations">
        <?php for($i=0;$i<25;$i++){
            echo '<div class="operation">
                <div class="icon"><img src="" style="background-color: red" width="50px" height="50px"></div>
                <div class="name">Example</div>
            </div>';}?>
            <div class="clear"></div>
        </div>
    </div>
    <div class="category">
        <div class="title">Modules</div>
        <div class="operations">
            <div class="operation">
                <div class="icon"><img src="" width="50px" height="50px"></div>
                <div class="name">Example</div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    <div class="category">
        <div class="title">Plugins</div>
        <div class="operations">
            <div class="operation">
                <div class="icon"><img src="" width="50px" height="50px"></div>
                <div class="name">Example</div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
</div>